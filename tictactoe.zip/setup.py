from cx_Freeze import setup, Executable


setup(name="TicTacToe", version="1.0", executables=[Executable("TicTacToe.py")])
