from cx_Freeze import setup, Executable


setup(name="isPrime", version="1.0", executables=[Executable("isPrime.py")])
